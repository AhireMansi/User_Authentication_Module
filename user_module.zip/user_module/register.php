<?php include 'db.php'; ?>
<form method="POST">
<input name="username" placeholder="Username" required>
<input name="email" type="email" placeholder="Email" required>
<input name="password" type="password" placeholder="Password" required>
<button name="register">Register</button>
</form>
<?php
if(isset($_POST['register'])){
$pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
$conn->query("INSERT INTO users(username,email,password) VALUES(
'$_POST[username]','$_POST[email]','$pass')");
header("Location: login.php");
}
?>