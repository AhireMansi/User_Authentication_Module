<?php include 'db.php';
if(!isset($_SESSION['user_id'])) header("Location: login.php");
$id=$_SESSION['user_id'];
$user=$conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();
?>
<form method="POST" action="update_profile.php">
<input name="username" value="<?=$user['username']?>" required>
<input name="email" value="<?=$user['email']?>" required>
<button>Update</button>
</form>
<a href="change_password.php">Change Password</a>
<a href="logout.php">Logout</a>