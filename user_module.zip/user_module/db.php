<?php
$conn = new mysqli("localhost", "root", "", "auth_system");
if ($conn->connect_error) die("DB Connection Failed");
session_start();
?>