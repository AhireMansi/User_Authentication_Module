<?php include 'db.php'; ?>
<form method="POST">
<input type="password" name="old" placeholder="Old Password" required>
<input type="password" name="new" placeholder="New Password" required>
<button name="change">Change</button>
</form>
<?php
if(isset($_POST['change'])){
$id=$_SESSION['user_id'];
$user=$conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();
if(password_verify($_POST['old'],$user['password'])){
$new=password_hash($_POST['new'],PASSWORD_DEFAULT);
$conn->query("UPDATE users SET password='$new' WHERE id=$id");
echo "Password updated";
}else echo "Wrong password";
}
?>