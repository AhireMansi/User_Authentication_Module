<?php include 'db.php';
$id=$_SESSION['user_id'];
$conn->query("UPDATE users SET username='$_POST[username]',email='$_POST[email]' WHERE id=$id");
header("Location: profile.php");
?>