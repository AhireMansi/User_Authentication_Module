<?php include 'db.php'; ?>
<form method="POST">
<input name="email" type="email" placeholder="Email" required>
<input name="password" type="password" placeholder="Password" required>
<button name="login">Login</button>
</form>
<?php
if(isset($_POST['login'])){
$res=$conn->query("SELECT * FROM users WHERE email='$_POST[email]'");
$user=$res->fetch_assoc();
if($user && password_verify($_POST['password'],$user['password'])){
$_SESSION['user_id']=$user['id'];
header("Location: profile.php");
}else echo "Invalid login";
}
?>